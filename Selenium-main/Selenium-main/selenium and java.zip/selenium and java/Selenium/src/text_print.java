
public class text_print {
	public static void main(String[] args) {
		System.out.println("------Printing------");
		
		
	}
}
