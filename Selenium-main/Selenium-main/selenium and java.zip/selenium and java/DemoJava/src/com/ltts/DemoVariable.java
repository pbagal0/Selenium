package com.ltts;

public class DemoVariable {
	 public static void main(String[] args) {
		 try
		 {
			 String a = "java";
			 int n = Integer.parseInt(a);
		 }
		 catch(NumberFormatException ne)
		 {
			 System.out.println(ne);
		 }
		 finally
		 {
			 System.out.println("finally block is evaluated");
		 }
		 System.out.println("Handled exc successfully");
	}
}
