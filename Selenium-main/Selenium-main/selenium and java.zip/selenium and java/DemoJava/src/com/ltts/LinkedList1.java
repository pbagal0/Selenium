package com.ltts;

import java.util.HashSet;

public class LinkedList1 {
	public static void main(String[] args) {
		HashSet h = new HashSet<>();
		h.add(10);
		h.add(15.4f);
		h.add(4.5);
		h.add("prashant");
		
		System.out.println(h);
	}
}
