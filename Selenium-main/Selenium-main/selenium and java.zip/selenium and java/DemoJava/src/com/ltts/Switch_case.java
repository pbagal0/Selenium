package com.ltts;

import java.util.Scanner;

public class Switch_case {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
	    System.out.println("enter i");
		int i = sc.nextInt();
	    
	    switch (i) {
		case 1:
			System.out.println("case 1");
			break;
		case 2:
			System.out.println("case 2");
			break;

		default:
			break;
		} 
	}

}
