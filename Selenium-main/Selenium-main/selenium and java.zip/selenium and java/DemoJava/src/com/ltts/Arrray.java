package com.ltts;

import java.util.Arrays;

public class Arrray {
	
	public static void main(String[] args) {
		char [] a = new char[10];
		a[0]='a';
		a[1]='b';
		a[3]='d';
		System.out.println(a);
	}

}
