package com.ltts;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class HashSet1 {
	public static void main(String[] args) {
		HashSet<Object> h = new HashSet<>();
		h.add(10);
		h.add(15.4f);
		h.add(4.5);
		h.add("prashant");
		
		System.out.println(h);
		
		LinkedHashSet<Object> h1 = new LinkedHashSet<>();
		
		h1.add(19);
		h1.add("ltts");
		h1.add(16.9f);
		
		
		System.out.println(h1);
	}
}
