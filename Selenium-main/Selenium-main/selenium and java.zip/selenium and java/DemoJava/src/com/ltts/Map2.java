package com.ltts;

import java.util.HashMap;
import java.util.Map;

public class Map2 {
	public static void main(String[] args) {
		Map map = new HashMap<>();
		
		map.put(1, "one");
		map.put(2, "two");
		map.put(3, "three");
		
		//for(Map.Entry m:map.entrySet())
		{
			//System.out.println(m.getKey());
		}
	}
}
