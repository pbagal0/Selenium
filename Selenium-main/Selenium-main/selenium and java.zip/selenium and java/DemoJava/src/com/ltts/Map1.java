package com.ltts;

import java.util.HashMap;

public class Map1 {
	public static void main(String[] args) {
		HashMap h  = new HashMap<>();
		
		h.put(1, "one");
		h.put(2, "two");
		h.put(3, "three");
		h.put(4, 16.2);
		h.put(5, "one");//duplicate values allowed
		
		h.put(4, 19);//duplicate keys not allowed
		
		System.out.println(h);
		System.out.println(h.entrySet());
		System.out.println(h.keySet());
		System.out.println(h.values());
	}
}
