package com.ltts;

import java.util.ArrayList;
import java.util.Collections;
public class DemoThread implements Runnable {
public void run() {
System.out.print(" running");
}
public static void main(String[] args) {
Thread t = new Thread(new DemoThread());
t.start(); // Line 7
t.start(); // Line 8
}
}
		

