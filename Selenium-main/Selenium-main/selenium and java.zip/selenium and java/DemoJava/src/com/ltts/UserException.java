package com.ltts;

class InvalidAgeException extends Exception
{
	public InvalidAgeException() {
		System.out.println("You are under age");
	}
}

public class UserException {
	public static void main(String[] args) throws InvalidAgeException {
		int age = 16;
		if (age<=18)
		{
			throw new InvalidAgeException();
		}
		else
		{
			System.out.println("Eligible");
		}
	}
}
