package com.ltts;

class parent 
{
	
}
public class Super {
	public static void main(String[] args) {
		int a;
	}
}
