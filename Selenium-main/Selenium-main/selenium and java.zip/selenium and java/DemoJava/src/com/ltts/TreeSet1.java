package com.ltts;
import java.util.TreeSet;
public class TreeSet1 {
	public static void main(String[] args) {
		TreeSet t = new TreeSet();
		
		t.add(10);
		//t.add(10.3);
		//t.add("hello");
		t.add(10);
		t.add(12);
		t.add(5);
		
		t.comparator();
	    
		System.out.println(t);
		
		System.out.println(t.comparator());
	}
}
