package com.ltts;

import java.util.Scanner;

public class forloop {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter value");
		
		for (int i = sc.nextInt();i<100;i++)
		{
			System.out.println(i);
		}
	}
}
