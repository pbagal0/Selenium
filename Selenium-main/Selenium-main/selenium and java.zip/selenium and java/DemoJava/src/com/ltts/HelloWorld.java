package com.ltts;

import java.util.Scanner;

public class HelloWorld {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Give value of a");
		int a = sc.nextInt();
		System.out.println("What is your Salary");
		int salary = sc.nextInt();
		if (a>=18)
		{
		System.out.println("Hello World Program");
		System.out.println("Hello PSB");
		}
	}
}
