package com.ltts;

import java.util.ArrayList;
import java.util.Iterator;

public class Array {
	//array holds similar data type elements or homogeneous
	//supports only fixed size
	//Array doesn't support built in function
	
	/*Collections:
	 Extension of array
	 takes homogeneous as well as heterogeneous elements
	 doesn't have fixed size mechanism
	 we can take value at run time,size internally increases
	 supports some built in methods
	 */
	
	public static void main(String[] args) {
			ArrayList a = new ArrayList();
		a.add(10);
		a.add("Pras");
		a.add("p");
		a.add(10);
		a.add(10.6);
		a.add(18.12f);
		System.out.println(a);
		
		
		ArrayList b = new ArrayList<>();
		b.addAll(a);
		
		System.out.println(b);
		
		System.out.println(a.contains(10));
		
		System.out.println(a.indexOf("Pras"));
		
		a.clear();
		System.out.println(a.isEmpty());
		
		
		/*
		ArrayList<Integer> a= new ArrayList<Integer>();
		
		a.add(1);
		a.add(2);
		a.add(30);
		System.out.println(a);
		
		Iterator i = a.iterator();
		
		while (i.hasNext())
		{
			System.out.println(i.next());
		}
		*/
		
	}
}
